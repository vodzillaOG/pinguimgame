
var MaxHeight, MaxWidth, YPos, XPos, interval1, interval2, interval3, interval4, moveTo , pontos = 0;    //adicionei a variavel counter para o contador da pontuaçao


backgroundAudio=document.getElementById("bgAudio");
backgroundAudio.volume=0.02;   //volume inicial do audio 0.02 para nao ser muito alto

function init(){  //funçao para determinar a posiçao inicial do pinguim, neste caso a sair do igloo
    XPos = 1050; //posiçao inicial do pinguim
    YPos = 388;
    toMoveChar = document.getElementById("character"); //em vez de mover o fundo, movemos o pinguim com o fundo estatico
    toMoveChar.style.top = YPos + "px ";
    toMoveChar.style.left = XPos + "px";
    moveSnowball(); //mover as bolas de neve
    moveSnowball1();
    moveSnowball2();

};

function move(){
    if ((YPos<=-10)||(YPos>=677)||(XPos<= 303)||(XPos>= 1582)) {   //determina os limites onde o pinguim para com o objetivo de não sair fora das margens
    stop();
	};

	toMoveChar = document.getElementById("character");
	toMoveChar.style.top = YPos + "px ";
	toMoveChar.style.left = XPos + "px";

	ganharPontos(); //ganhar pontos consoante visitados os pontos de interesse
	ganharPontos1();
	ganharPontos2();
	ganharPontos3();
	ganharPontos4();
};

function moveBx() {
    var myclass = new Array('front-right','front-stand','front-left');
    var n= Math.round(Math.random()*2);
    document.getElementById('character').setAttribute('class',myclass[n]);
    YPos++;
    move();
};

function moveCm() {
    var myclass = new Array('back-right','back-stand','back-left');
    var n= Math.round(Math.random()*2);
    document.getElementById('character').setAttribute('class',myclass[n]);
    YPos--;
    move();
};

function moveDir() {
    var myclass = new Array('right-right','right-stand','right-left');
    var n= Math.round(Math.random()*2);
    document.getElementById('character').setAttribute('class',myclass[n]);
    XPos++;
    move();
};

function moveEsq() {
    var myclass = new Array('left-right','left-stand','left-left');
    var n= Math.round(Math.random()*2);
    document.getElementById('character').setAttribute('class',myclass[n]);
    XPos--;
    move();
};

function moveB() {
    stop();
    interval1 = setInterval(moveBx, 11);  //determina velocidade do pinguim, quanto mais baixo o numero mais alto o pinguim
};

function moveC() {
    stop();
    interval3 = setInterval(moveCm, 11);
};

function moveD() {
    stop();
    interval2 = setInterval(moveDir, 11);
};

function moveE() {
    stop();
    interval4 = setInterval(moveEsq, 11);
};

function stop() {
    clearInterval(interval1);
    clearInterval(interval2);
    clearInterval(interval3);
    clearInterval(interval4);
};

window.onload =init;

function Key(e) {
    if (e.keyCode===37) moveE();
    if (e.keyCode===38) moveC();
    if (e.keyCode===39) moveD();
    if (e.keyCode===40) moveB();
    if (e.keyCode===17) stop(); //acrescentei a tecla Ctrl para parar o pinguim
}

function moveSnowball() { //mover a primeira bola
    var elem = document.getElementById("snowball"), //utilizar o ficheiro de snowball definido no css
    speedX = 5;
    currentPosX = 100;
	currentPosY = 30;

    elem.style.left = 0 +"px";
    elem.style.right = "auto";

    var motionInterval = setInterval(function() {
    currentPosX += speedX;
		//alterar a trajetoria quando sao atingidos os limites
    if (currentPosX >= 1582) {
        currentPosX = 1582;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

      if (currentPosX <= 303) {
        currentPosX = 303;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

        elem.style.left = currentPosX+"px";
        elem.style.top = currentPosY + "px";

		if(currentPosX <= XPos + 10 && currentPosX >= XPos - 5 && currentPosY  + 76 <= YPos + 30 && currentPosY  + 76 >= YPos - 30) {
			alert(" :( YOU LOST "); //caso seja acertado com a bola perde o jogo
			location.reload();			//a janela do jogo e recarregada depois do popup
		}
  },20);
}

function moveSnowball1() { //mover a segunda bola
  var elem = document.getElementById("ball1"),
  speedX = 5;
  currentPosX = 120;
  currentPosY = 20;

  elem.style.left = 0 + "px";
  elem.style.right = "auto";

  var motionInterval = setInterval(function() {
    currentPosX +=speedX;

    if (currentPosX >= 1582) {
        currentPosX = 1582;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

      if (currentPosX <= 303) {
        currentPosX = 303;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

        elem.style.left = currentPosX+"px";
        elem.style.top = currentPosY + "px";

		if(currentPosX <= XPos + 10 && currentPosX >= XPos - 5 && currentPosY  + 301 <= YPos + 30 && currentPosY  + 301 >= YPos - 30) {
			alert(" :( YOU LOST ");
			location.reload();
		}
  },20);
}

function moveSnowball2() {
  var elem = document.getElementById("ball2"),
  speedX = 5;
  currentPosX = 120;
  currentPosY = 20;

  elem.style.left = 0 + "px";
  elem.style.right = "auto";

  var motionInterval = setInterval(function() {
    currentPosX +=speedX;

    if (currentPosX >= 1582) {
        currentPosX = 1582;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

      if (currentPosX <= 303) {
        currentPosX = 303;
        speedX = -1 * speedX;
        elem.style.width = parseInt(elem.style.width)*2+"px";
        elem.style.height = parseInt(elem.style.height)*2+"px";
      }

        elem.style.left = currentPosX+"px";
        elem.style.top = currentPosY + "px";

		if(currentPosX <= XPos + 10 && currentPosX >= XPos - 5 && currentPosY  + 601 <= YPos + 30 && currentPosY  + 601 >= YPos - 30) {
			alert(" :( YOU LOST ");
			location.reload();
		}
  },20);
}


function ganharPontos(){ //funçao para acrescentar pontos no SCORE
  pontos = parseInt(document.getElementById("score").innerHTML);
  if ((XPos == 955) && (YPos<=155) && (YPos>= 70)) { //ponto de interesse
	  pontos++;

	  if (pontos >= 5){
		  alert("You won!!!!"); //caso atinja 5 pontos ganha o jogo
		  location.reload();
	  }
	  document.getElementById("score").innerHTML=pontos;
  }
}

function ganharPontos1(){
  pontos = parseInt(document.getElementById("score").innerHTML);
  if ((XPos == 633) && (YPos<=135) && (YPos>= 65)) {
	  pontos++;

	  if (pontos >=5){
		  alert("Winning!");
		  location.reload();
	  }
	  document.getElementById("score").innerHTML=pontos;
  }
}

function ganharPontos2(){
  pontos = parseInt(document.getElementById("score").innerHTML);
  if ((XPos == 540) && (YPos<=310) && (YPos>= 232)) {
	  pontos++;

	  if (pontos >=5){
		  alert("Winning!");
		  location.reload();
	  }
	  document.getElementById("score").innerHTML=pontos;
  }
}

function ganharPontos3(){
  pontos = parseInt(document.getElementById("score").innerHTML);
  if ((XPos == 748) && (YPos<=632) && (YPos>= 548)) {
	  pontos++;

	  if (pontos >=5){
		  alert("Winning!");
		  location.reload();
	  }
	  document.getElementById("score").innerHTML=pontos;
  }
}

function ganharPontos4(){
  pontos = parseInt(document.getElementById("score").innerHTML);
  if ((XPos== 1427) && (YPos<=366) && (YPos>= 275)) {
	  pontos++;

	  if (pontos >=5){
		  alert("Winning!");
		  location.reload();
	  }
	  document.getElementById("score").innerHTML=pontos;
  }
}
